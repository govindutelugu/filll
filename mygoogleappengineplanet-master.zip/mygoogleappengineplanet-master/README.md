# mygoogleappengineplanet

This repository is used in the following blog post: https://mydeveloperplanet.com/2019/04/10/deploy-spring-boot-app-to-gcp-app-engine/
