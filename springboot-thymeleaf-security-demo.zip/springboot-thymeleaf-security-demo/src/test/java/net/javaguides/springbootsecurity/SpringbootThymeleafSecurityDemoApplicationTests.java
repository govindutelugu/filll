package net.javaguides.springbootsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootThymeleafSecurityDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
